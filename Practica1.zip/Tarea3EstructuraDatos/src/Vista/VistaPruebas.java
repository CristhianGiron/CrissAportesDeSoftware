/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import controlador.tmControl;

/**
 *
 * @author Cristhian Girón
 */
public class VistaPruebas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(11+2/2);
        // TODO code application logic here
    }
    
}
