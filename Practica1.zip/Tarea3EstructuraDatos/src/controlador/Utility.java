/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import Modelo.Temperaturas;
import java.util.Arrays;

/**
 *
 * @author Cristhian Girón
 */
public class Utility {
   public static void cargarArreglo(Object[] listado, Object[]temp){
        for (int i = 0; i < temp.length; i++) {
            listado[i]=temp[i];
        }
    }
    public static void imprimirArreglo(Object[] x){
        Arrays.asList(x).forEach(y->System.out.print(y+"\t"));
        
    }
    public void ordenar(Temperaturas[] listado,Temperaturas[]listadoOrdenado){
        for (int i = 0; i < listado.length; i++) {
            listadoOrdenado[i]=listado[i];
        }
    }
}
