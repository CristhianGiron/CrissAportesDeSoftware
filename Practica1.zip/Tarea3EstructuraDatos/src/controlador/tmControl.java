/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import Modelo.Temperaturas;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author Cristhian Girón
 */
public class tmControl {

    Temperaturas[] listado;
    Temperaturas[] temp;
    Temperaturas[] listadoOrdenado;
    Temperaturas temperatura;
    Utility uti = new Utility();
    int maximo = 0;
    Componentes comp = new Componentes();

    public Temperaturas[] getListado() {
        return listado;
    }

    public void setListado(Temperaturas[] listado) {
        this.listado = listado;
    }

    public Temperaturas[] getTemp() {
        return temp;
    }

    public void setTemp(Temperaturas[] temp) {
        this.temp = temp;
    }

    public Temperaturas getTemperatura() {
        if (temperatura == null) {
            temperatura = new Temperaturas();
        }
        return temperatura;
    }

    public void setTemperatura(Temperaturas temperatura) {
        this.temperatura = temperatura;
    }

    public void crearArreglo(int size) {
        listado = new Temperaturas[size];
    }

    public Temperaturas fijarTemperaturas() {
        Temperaturas aux = new Temperaturas();
        aux.settMaxima(temperatura.gettMaxima());
        aux.settMinima(temperatura.gettMinima());
        aux.setTmedia(temperatura.getTmedia());
        aux.setIndice(temperatura.getIndice());
        return aux;   //To change body of generated methods, choose Tools | Templates.
    }

    public void llenarTabla(JTable tabla) {
        Componentes comp = new Componentes();
        Object obj[] = new Object[4];
        if (listado.length >= 1) {
            comp.modelo(tabla).setRowCount(0);
            for (int i = 0; i < listado.length; i++) {
                obj[0] = listado[i].getIndice();
                obj[1] = listado[i].gettMinima();
                obj[2] = listado[i].gettMaxima();
                obj[3] = listado[i].getTmedia();
                comp.modelo(tabla).addRow(obj);
            }
        }
    }

    public double media(JTextField txt1, JTextField txt2) {
        double media = (((double) Integer.valueOf(txt1.getText()) + (double) Integer.valueOf(txt2.getText())) / 2);
        System.out.println("\nMedia: " + media);
        return media;
    }

    static void imprimeArrayPersonas(Temperaturas[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.println("ordenado: \n" + array[i].getIndice() + " " + array[i].gettMaxima() + " " + array[i].gettMinima() + " " + array[i].getTmedia());
        }
    }

    public double Mayor() {
        double mayor = 0;
        for (int i = 0; i < listado.length; i++) {
            if (listado[i].getTmedia() > mayor) {
                mayor = listado[i].getTmedia();
            }
        }
        return mayor;

    }

    public double Menor() {
        double menor = 900;
        for (int i = 0; i < listado.length; i++) {
            if (listado[i].getTmedia() < menor) {
                menor = listado[i].getTmedia();
            }
        }
        return menor;

    }

    public void llenarMenor(JTable jt) {
        Object obj[] = new Object[4];
        if (listado.length >= 1) {
            comp.modelo(jt).setRowCount(0);
            for (int i = 0; i < listado.length; i++) {
                if (listado[i].getTmedia() == Menor()) {
                    obj[0] = listado[i].getIndice();
                    obj[1] = listado[i].gettMinima();
                    obj[2] = listado[i].gettMaxima();
                    obj[3] = listado[i].getTmedia();
                    comp.modelo(jt).addRow(obj);
                }

            }

        }
    }

    public void llenarMayor(JTable jt) {
        Object obj[] = new Object[4];
        if (listado.length >= 1) {
            comp.modelo(jt).setRowCount(0);
            for (int i = 0; i < listado.length; i++) {
                if (listado[i].getTmedia() == Mayor()) {
                    obj[0] = listado[i].getIndice();
                    obj[1] = listado[i].gettMinima();
                    obj[2] = listado[i].gettMaxima();
                    obj[3] = listado[i].getTmedia();
                    comp.modelo(jt).addRow(obj);
                }

            }
        }

    }

    public void llenarTablaOrdenada(JTable tabla, Temperaturas[] array) {

        if (array.length > 3) {
            Object obj[] = new Object[4];
            comp.modelo(tabla).setRowCount(0);

            for (int i = 0; i < (array.length / 3); i++) {
                obj[0] = array[i].getIndice();
                obj[1] = array[i].gettMinima();
                obj[2] = array[i].gettMaxima();
                obj[3] = array[i].getTmedia();
                comp.modelo(tabla).addRow(obj);
            }
        } else {
            JOptionPane.showMessageDialog(null, "No existen los suficientes datos para relizar esta operación");
        }

    }

    public Temperaturas[] BuscarDiasMenor() {
        listadoOrdenado = new Temperaturas[listado.length];
        uti.ordenar(listado, listadoOrdenado);
        Arrays.sort(listadoOrdenado);
        imprimeArrayPersonas(listadoOrdenado);
        return listadoOrdenado;

    }

    public void rangue(int min, int max, JTable tabla) {
        Object obj[] = new Object[4];
        comp.modelo(tabla).setRowCount(0);
        System.out.println("Tamaño: " + listado.length);
        boolean verificar = false;
        for (int i = 0; i < listado.length; i++) {
            System.out.println("hola " + max);
            if (listado[i].gettMaxima() >= min && listado[i].gettMaxima() <= max) {
                verificar = true;
                obj[0] = listado[i].getIndice();
                obj[1] = listado[i].gettMinima();
                obj[2] = listado[i].gettMaxima();
                obj[3] = listado[i].getTmedia();
                comp.modelo(tabla).addRow(obj);
            }
        }
        if (verificar) {
            System.out.println("Si existen datos en ese rango");
        } else {
            JOptionPane.showMessageDialog(null, "No hay datos para mostrar en el rango: " + min + " - " + max);
        }
    }

}
