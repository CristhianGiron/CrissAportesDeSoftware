/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author Cristhian Girón
 */
public class Temperaturas implements Comparable {
    int tMinima;
    int tMaxima;
    double tmedia;
    int indice;

    public double getTmedia() {
        return tmedia;
    }

    public void setTmedia(double tmedia) {
        this.tmedia = tmedia;
    }

    public int getIndice() {
        return indice;
    }

    public void setIndice(int indice) {
        this.indice = indice;
    }

    public int gettMinima() {
        return tMinima;
    }

    public void settMinima(int tMinima) {
        this.tMinima = tMinima;
    }

    public int gettMaxima() {
        return tMaxima;
    }

    public void settMaxima(int tMaxima) {
        this.tMaxima = tMaxima;
    }

    @Override
    public String toString() {
        return tMinima+" "+tMaxima; //To change body of generated methods, choose Tools | Templates.
    }

     //To change body of generated methods, choose Tools | Templates.

    @Override
    public int compareTo(Object o) {
        Temperaturas t = (Temperaturas) o;
         if (tmedia <t.tmedia) {
                return -1;
            }
            if (tmedia >t.tmedia) {
                return 1;
            }
            return 0;
        //To change body of generated methods, choose Tools | Templates.
    }
    
    }

    


