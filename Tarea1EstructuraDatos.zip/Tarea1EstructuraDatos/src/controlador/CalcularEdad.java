/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

/**
 *
 * @author Cristhian Girón
 */
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class CalcularEdad {

    public static Integer Edad(String fecha) {
        Date fechaNac = null;
        try {
            System.out.println("fecha inicial: "+fecha);
            fechaNac = new SimpleDateFormat("dd-MM-yyyy").parse(fecha);
        } catch (Exception ex) {
            System.out.println("Error:" + ex);
        }
        Calendar fechaNacimiento = Calendar.getInstance();
        Calendar fechaActual = Calendar.getInstance();
        fechaNacimiento.setTime(fechaNac);
        int año = fechaActual.get(Calendar.YEAR) - fechaNacimiento.get(Calendar.YEAR);
        int mes = fechaActual.get(Calendar.MONTH) - fechaNacimiento.get(Calendar.MONTH);
        int dia = fechaActual.get(Calendar.DATE) - fechaNacimiento.get(Calendar.DATE);
        if (mes < 0 || (mes == 0 && dia < 0)) {
            año--;
        }
        return año;
    }
    public static Integer Mayor(ArrayList<Integer> ListaEdad){
        int mayor=0;
        for (int i = 0; i < ListaEdad.size(); i++) {
            if (ListaEdad.get(i)>mayor) {
                mayor=ListaEdad.get(i);
            }
        }
        return mayor;
        
    }
     public static Integer Menor(ArrayList<Integer> ListaEdad){
        int menor=900;
        for (int i = 0; i < ListaEdad.size(); i++) {
            if (ListaEdad.get(i)<menor) {
                menor=ListaEdad.get(i);
            }
        }
        return menor;
        
    }
}
