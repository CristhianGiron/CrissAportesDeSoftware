/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Cristhian Girón
 */
public class Conductor {
    private String nombre;
    private String cedula;
    private String ClaseLicencia;

    public Conductor(String nombre) {
        this.nombre = nombre;
    }

    public Conductor(String nombre, String cedula, String ClaseLicencia) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.ClaseLicencia = ClaseLicencia;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getClaseLicencia() {
        return ClaseLicencia;
    }

    public void setClaseLicencia(String ClaseLicencia) {
        this.ClaseLicencia = ClaseLicencia;
    }
    
    

    
    
}
