/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Conductor;
import Modelo.RegistroConductor;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Cristhian Girón
 */
public class ControladorConductor {
    RegistroConductor listado[] = new RegistroConductor[1];
    int indice=1;

    public RegistroConductor[] getListado() {
        return listado;
    }

    public void setListado(RegistroConductor[] listado) {
        this.listado = listado;
    }
    
    
    public void registroO(RegistroConductor conductor, RegistroConductor [] lista){
        for (int i = 0; i < lista.length; i++) {
            if (lista[i]==null) {
                lista[i]=conductor;
            }
        }
    }
    
    public RegistroConductor[] registroN(RegistroConductor [] lista){
        RegistroConductor[] lista1=new RegistroConductor[lista.length+1];
        for (int i = 0; i < lista.length; i++) {            
                lista1[i]=lista[i];
        }
        return lista1;
        
    }
    public void llenarTable(JTable tabla,DefaultTableModel modelo) {
        Object obj[] = new Object[7];
        if (listado.length >= 1) {
            modelo.setRowCount(0);
            for (int i = 0; i < listado.length; i++) {
                obj[0] = listado[i].getConductor().getNombre();
                obj[1] = listado[i].getMonday()+" Km";
                obj[2] = listado[i].getTuesday()+" Km";
                obj[3] = listado[i].getWednesday()+" Km";
                obj[4] = listado[i].getThursday()+" Km";
                obj[5] = listado[i].getFriday()+" Km";
                obj[6] = listado[i].getMonday()+listado[i].getTuesday()+listado[i].getWednesday()+listado[i].getThursday()+listado[i].getFriday()+" Km";
                modelo.addRow(obj);
            }
        }
    }
    public void nuevos(JTextField txtNombre,JTextField txtCedula,JTextField txtClase,JComboBox cbxConductor,JTable Tabla1,DefaultTableModel modelo){
        RegistroConductor cond;
                    cond = new RegistroConductor(new Conductor(txtNombre.getText(),txtCedula.getText(),txtClase.getText()),0,0,0,0,0);
                    if (indice > 1) {
                        listado = registroN(listado);
                        registroO(cond, listado);
                    } else {
                        registroO(cond, listado);
                    }
                    indice++;
                    cbxConductor.addItem(txtNombre.getText());
                    llenarTable(Tabla1,modelo); 
    }
    public void info(int indiceT,JLabel txtInfo){
        String nombre=listado[indiceT].getConductor().getNombre();
        String cedula=listado[indiceT].getConductor().getCedula();
        String clase=listado[indiceT].getConductor().getClaseLicencia();
        String text= "<html>\n" +
                "<font color=blue size=+1 ><b>Informacio de Conductores:</b></font> \n" +
                "<ul>\n" +
                "<li><font color=green><b>Nombre: </b>"+nombre+"</font>\n" +
                "<li><font color=green><b>Cedula: </b>"+cedula+"</font>\n" +
                "<li><font color=green><b>Clase: </b>"+clase+"</font>\n" +
                
                
                "</ul>\n";
        txtInfo.setText(text);
    }
    
}
