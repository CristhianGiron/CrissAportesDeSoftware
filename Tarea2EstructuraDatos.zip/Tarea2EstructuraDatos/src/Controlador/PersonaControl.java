/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Cliente;
import java.util.Scanner;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Cristhian Girón
 */
public class PersonaControl {

    private Cliente[] listado;
    private Cliente cliente;
    private Cliente[] temp;

    public Cliente[] getTemp() {
        return temp;
    }

    public void setTemp(Cliente[] temp) {
        this.temp = temp;
    }

    public Cliente[] getListado() {
        return listado;
    }

    public void setListado(Cliente[] listado) {
        this.listado = listado;
    }

    public Cliente getCliente() {
        if (cliente == null) {
            cliente = new Cliente();
        }
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void crearArregloCliente(int size) {
        listado = new Cliente[size];
    }

    public void cargarArregloCliente() {
        Scanner sn = new Scanner(System.in);
        System.out.println("INGRESE LOS DATOS: ");
        for (int i = 0; i < listado.length; i++) {
            System.out.println("INGRESE CLIENTE: ");
            listado[i] = new Cliente();
            listado[i].setNombres(sn.nextLine());
            System.out.println("INGRESE LA CEDULA: ");
            listado[i].setCedula(sn.nextLine());
            System.out.println("INGRESE LA DIRECCION: ");
            listado[i].setDireccion(sn.nextLine());

        }
    }

    public Cliente fijarCliente() {
        Cliente aux = new Cliente();
        aux.setCedula(cliente.getCedula());
        aux.setNombres(cliente.getNombres());
        aux.setDireccion(cliente.getDireccion());
        aux.setId(cliente.getId());
        return aux;   //To change body of generated methods, choose Tools | Templates.
    }

    public void ImprimirTabla(DefaultTableModel modelo) {
        Object obj[] = new Object[4];
        modelo.setRowCount(0);
        for (int i = 0; i < listado.length; i++) {
            obj[0] = listado[i].getId();
            obj[1] = listado[i].getNombres();
            obj[2] = listado[i].getCedula();
            obj[3] = listado[i].getDireccion();
            modelo.addRow(obj);
        }

    }

    public void buscar(String look, DefaultTableModel modelo) {
        Object objB[] = new Object[4];
        for (int i = 0; i < listado.length; i++) {
            if (listado[i].getCedula().equals(look)) {
                modelo.setRowCount(0);
                objB[0] = listado[i].getId();
                objB[1] = listado[i].getNombres();
                objB[2] = listado[i].getCedula();
                objB[3] = listado[i].getDireccion(); 
                modelo.addRow(objB);
                JOptionPane.showMessageDialog(null, "Encontardo");
                
            }
        }
    }
    public void actualizarCampo(String look,JTextField Nombre,JTextField cedula,JTextArea Direccion,JLabel lb1,JLabel lb2){
        for (int i = 0; i < listado.length; i++) {
            if (listado[i].getCedula().equals(look)) {
               
                Nombre.setText(listado[i].getNombres());
                cedula.setText(listado[i].getCedula());
                Direccion.setText(listado[i].getDireccion());
                Nombre.setEditable(false);
                cedula.setEditable(false);
                lb1.setText("No editable");
                lb2.setText("No editable");
                 
                
            }
        }
    }
    public void modificar(String look,String Direccion) {
        
        for (int i = 0; i < listado.length; i++) {

            if (listado[i].getCedula().equals(look)) {
                if (Direccion.length() > 0){
                    listado[i].setDireccion(Direccion);
                    JOptionPane.showMessageDialog(null, "Direccion modificada");
                }

            }
        }
    }
}
