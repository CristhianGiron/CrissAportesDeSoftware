/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.util.Arrays;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Cristhian Girón
 */
public class Utiles {
    public static void imprimirArreglo(Object[] x){
        Arrays.asList(x).forEach(y->System.out.print(y+"\t"));
        
    }
    public static void cargarArreglo(Object[] listado, Object[]temp){
        for (int i = 0; i < temp.length; i++) {
            listado[i]=temp[i];
        }
    }
}
